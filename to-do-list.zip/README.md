# To do list 

#### ¿Qué es?
<p>To Do List es un pequeño proyecto que puede definirse como una lista donde se pueden anotar tareas pendientes por el usuario.</p>

#### ¿Qué contiene?
<p>Está compuesto por dos secciones principales, la primera contiene un input que puede recibir las tareas del usuario, y la segunda parte que se escuentra justo debajo es la que almacena y muestra estas tasks.</p>

#### ¿Cómo funciona?
<p>En la primera sección el usuario introduce el texto en el input, justo al lado se muestra un botón que se encarga de recuperar la tarea, guardarla y mostrarla en la sección posterior.

Una vez mostrada la tarea en la parte de abajo, esta aparece con un icono en el lateral izquierdo que al hacer click se marca la tarea como completada y viceversa. En el lateral derecho se muestra un icono con una X que permite eliminar la tarea de la lista.</p>
